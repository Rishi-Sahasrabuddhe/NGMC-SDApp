<?php

declare(strict_types=1);

namespace thebridge;

use pocketmine\plugin\PluginBase;

class Main extends PluginBase
{
    
}
